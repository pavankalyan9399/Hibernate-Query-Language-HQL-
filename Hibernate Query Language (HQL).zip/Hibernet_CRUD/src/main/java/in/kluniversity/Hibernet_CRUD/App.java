package in.kluniversity.Hibernet_CRUD;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	StandardServiceRegistry ssr= new StandardServiceRegistryBuilder().configure("hibernate.hbm.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
      
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();  
        Transaction t;
        Student s1 = new Student();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1 to insert, 2 --> view,3--> update,4--. delete");
        int k=sc.nextInt();
        if(k==1) {
       
        s1.Fn = "Sujay";
        s1.Ln = "Chowdary";
        t= session.beginTransaction();
        t.commit();
        
        System.out.println("Record Created");
        }
        else if(k==2)
        {
        	Student s2=session.find(Student.class,52);
            System.out.println("Student Record Retived");
            System.out.println(s2);
        }
        else if(k==3)
        {
        	  t= session.beginTransaction();
        	Student s3= session.get(Student.class,52);
        	s3.setFn("Iron");
        	s3.setLn("Man");
        	session.update(s3);
        	t.commit();
        	System.out.println("updated succuseefulluy");
        }
        else
        {
        	t=session.beginTransaction();
        	Student s4=session.get(Student.class,202);
        	session.delete(s4);
        	t.commit();
        	System.out.println("Record Deleted");
        }
       		

    }
}
